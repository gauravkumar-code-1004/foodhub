import React from "react";
import * as ReactDOM from "react-dom/client";
import Header from './Components/Header'
import Body from "./Components/Body";
import Menu from "./Components/Menu";
import Cart from "./Components/Cart"
import { Outlet, createBrowserRouter } from "react-router-dom";
import { RouterProvider } from "react-router-dom";
import { Provider, useSelector } from "react-redux";
import Store from "./utils/Store";
import useMenu from "./utils/Hooks/useMenu";
import { menuData } from "./utils/menuData";

const App = () => {

  // const menu = useSelector((store) => store.restro.menuData);
  // console.log(menu)
        // useMenu("361755");
  return (

    <div>
      <Provider store={Store}>
        <Header />
        <Outlet />
      </Provider>
    </div>


  );
};

const routedData = createBrowserRouter([
  {
    path: "/",
    element: <App />,
    children: [

      {
        path: "Cart",
        element: <Cart />
      },
      {
        path: "/",
        element: <Body />
      },
      {
        path: "/rest/:id",
        element: <Menu />
      }

    ]
  }




])



let root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<RouterProvider router={routedData} />);
