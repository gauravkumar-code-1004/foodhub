import useData from "../utils/Hooks/useData"


const Shimmer = () => {


    const divsArray = Array.from({ length: 8 });

    return (

        <div className="animate-pulse">



            <div className="flex flex-col  p-4 sm:items-center  md:items-center ">

            

                <div className=" w-full flex  gap-6  justify-center md:justify-center " >


                    <button className=" bg-gray-400 hover:bg-gray-800 px-2 py-1 rounded-lg text-gray-400 ">Top Rated</button>
                    <button className=" bg-gray-400 hover:bg-gray-800 px-2 py-1 rounded-lg text-gray-400 ">Fast Delivery </button>
                    <button className=" bg-gray-400 hover:bg-gray-800 px-2 py-1 rounded-lg text-gray-400 ">Veg </button>
                </div>
            </div>
            <div className="flex gap-2 flex-wrap justify-center ">


                <div className="flex gap-2 flex-wrap justify-center">
                    {divsArray.map((_, index) => (
                        <div
                            key={index}
                            className="bg-gray-400 rounded-xl m-4 w-60"
                            style={{ height: 300 }}
                        ></div>
                    ))}
                </div>



            </div>
        </div>

    )
}
export default Shimmer
