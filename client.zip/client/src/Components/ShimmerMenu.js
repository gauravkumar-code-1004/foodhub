import React from 'react'

const ShimmerMenu = () => {
    return (

        <div className=' items-center  '>

            <div className="   flex justify-center   ">
                <div className=" mb-2 bg-neutral-800 animate-pulse w-full h-screen sm:w-1/2 sm:rounded-xl mt-2 p-4 ">
                </div>
            </div>
        </div >

    )
}

export default ShimmerMenu