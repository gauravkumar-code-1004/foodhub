import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { clearCart } from "../utils/cartSlice";
import AccBody from "./AccBody";

const Cart = () => {
    const [totalPrice, setTotalPrice] = useState(0);
    const cartItems = useSelector((store) => store.cart.items)
    const dispatch = useDispatch();
    let total = cartItems.reduce((acc, item) => acc + item.card.info.price, 0)
    
    const formateNum = (total) => {
        return (total / 100).toFixed(2)
    }
    useEffect(() => {
        formateNum(total)
        setTotalPrice(prev => prev + total)
    }, [])
    console.log(total)
    const handleClearCart = () => {
        dispatch(clearCart())
    }
    return (
        <div className="flex flex-col items-center ">
            <div className=" w-1/2 flex flex-col items-center  m-auto p-4  ">
                <h1 className="text-2xl mb-2 ">Cart</h1>
                <button className="p-2 " onClick={handleClearCart}>clear </button>
            </div>
            <div className="w-3/4 m-auto  ">
                {cartItems.length === 0 ? <h1 className=" text-center">Cart is empty </h1> :
                    <AccBody items={cartItems} msg={"remove"} />

                }


            </div>
            <div className="flex  justify-between fixed  rounded-lg py-2 border border-neutral-200 bottom-2 bg-neutral-700 w-1/2">
                <h1 className="text-lg ml-12">
                    Total
                </h1>
                <h1 className="text-lg mr-12 "> RS. {total}</h1>

            </div>
        </div>
    )
}
export default Cart;
