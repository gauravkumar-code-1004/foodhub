export const menuData = {
    "statusCode": 0,
    "data": {
        "statusMessage": "done successfully",
        "cards": [
            {
                "card": {
                    "card": {
                        "@type": "type.googleapis.com/swiggy.presentation.food.v2.Restaurant",
                        "info": {
                            "id": "289667",
                            "name": "CHAKHNA DE BHAI",
                            "city": "Allahabad",
                            "slugs": {
                                "restaurant": "chakhna-de-bhai-civil-lines-civil-lines",
                                "city": "allahabad"
                            },
                            "uniqueId": "e51e6528-4859-48c8-8fed-e84c17dc2d76",
                            "cloudinaryImageId": "uafncwsb6ovxvsq8ledw",
                            "locality": "Civil Lines",
                            "areaName": "Civil Lines",
                            "costForTwo": "20000",
                            "costForTwoMessage": "₹200 for two",
                            "cuisines": [
                                "Default"
                            ],
                            "feeDetails": {
                                "restaurantId": "289667",
                                "fees": [
                                    {}
                                ]
                            },
                            "parentId": "57433",
                            "avgRatingString": "--",
                            "totalRatingsString": "Too Few Ratings",
                            "sla": {
                                "restaurantId": "289667",
                                "serviceability": "NON_SERVICEABLE",
                                "nonServiceableReason": "NON_SERVICEABLE_REASON_NON_BATCHABLE_ACTIVE_ORDER",
                                "rainMode": "RAIN_MODE_NONE",
                                "iconType": "ICON_TYPE_EMPTY"
                            },
                            "availability": {
                                "visibility": true,
                                "restaurantClosedMeta": {}
                            },
                            "aggregatedDiscountInfo": {
                                "shortDescriptionList": [
                                    {
                                        "discountType": "Percentage",
                                        "operationType": "RESTAURANT"
                                    },
                                    {
                                        "discountType": "Flat",
                                        "operationType": "RESTAURANT"
                                    }
                                ],
                                "descriptionList": [
                                    {
                                        "meta": "20% off up to ₹120 | Use FEDERALCC Above ₹299",
                                        "discountType": "Percentage",
                                        "operationType": "RESTAURANT"
                                    },
                                    {
                                        "meta": "Flat ₹120 off | Use AXIS120 Above ₹500",
                                        "discountType": "Flat",
                                        "operationType": "RESTAURANT"
                                    }
                                ],
                                "visible": true
                            },
                            "badges": {},
                            "slugString": "chakhna-de-bhai-civil-lines-civil-lines",
                            "labels": [
                                {
                                    "title": "Timings",
                                    "message": "null"
                                },
                                {
                                    "title": "Address",
                                    "message": "Civil lines Allahabad Payangraj , Allahabad ,211001"
                                },
                                {
                                    "title": "Cuisines",
                                    "message": "Default"
                                }
                            ],
                            "aggregatedDiscountInfoV2": {
                                "shortDescriptionList": [
                                    {
                                        "discountType": "Percentage",
                                        "operationType": "RESTAURANT"
                                    },
                                    {
                                        "discountType": "Flat",
                                        "operationType": "RESTAURANT"
                                    }
                                ],
                                "descriptionList": [
                                    {
                                        "meta": "20% off up to ₹120 | Use FEDERALCC Above ₹299",
                                        "discountType": "Percentage",
                                        "operationType": "RESTAURANT"
                                    },
                                    {
                                        "meta": "Flat ₹120 off | Use AXIS120 Above ₹500",
                                        "discountType": "Flat",
                                        "operationType": "RESTAURANT"
                                    }
                                ],
                                "couponDetailsCta": "View coupon details"
                            },
                            "type": "F",
                            "headerBanner": {
                                "url": "swiggy://webview?is_external=false&webview_url=https://www.swiggy.com/restaurant-info/289667"
                            },
                            "availabilityServiceabilityMessage": "Does not deliver to your location",
                            "orderabilityCommunication": {
                                "title": {
                                    "text": "Wish you were"
                                },
                                "subTitle": {
                                    "text": "CLOSER!"
                                },
                                "message": {
                                    "text": "This location is outside the outlet's delivery area",
                                    "textColour": "negative"
                                },
                                "customIcon": {
                                    "bgGradientColorStart": "#F64C41",
                                    "bgGradientColorEnd": "#E53554"
                                }
                            },
                            "cartOrderabilityNudgeBanner": {
                                "parameters": {},
                                "presentation": {}
                            },
                            "latLong": "25.452327,81.834513"
                        },
                        "analytics": {}
                    },
                    "relevance": {
                        "type": "RELEVANCE_TYPE_CHECK_ORDERABILITY_ON_ITEM_ADD",
                        "sectionId": "POP_UP_CROUTON_MENU"
                    }
                }
            },
            {
                "card": {
                    "card": {
                        "@type": "type.googleapis.com/swiggy.gandalf.widgets.v2.GridWidget",
                        "layout": {
                            "rows": 1,
                            "columns": 2,
                            "horizontalScrollEnabled": true,
                            "itemSpacing": 12,
                            "lineSpacing": 10,
                            "widgetPadding": {},
                            "containerStyle": {
                                "containerPadding": {
                                    "left": 10,
                                    "right": 10,
                                    "bottom": 16
                                }
                            },
                            "scrollBar": {}
                        },
                        "id": "offerCollectionWidget_UX4",
                        "gridElements": {
                            "infoWithStyle": {
                                "@type": "type.googleapis.com/swiggy.presentation.food.v2.OfferInfoWithStyle",
                                "offers": [
                                    {
                                        "info": {
                                            "header": "20% OFF UPTO ₹120",
                                            "offerTagColor": "#E46D47",
                                            "logoBottom": "rng/md/ads/production/1acdb97aadcb61b323307845bda86535",
                                            "offerIds": [
                                                "f06350cb-9abf-4952-b57c-8cccf46b1789"
                                            ],
                                            "expiryTime": "1970-01-01T00:00:00Z",
                                            "couponCode": "USE FEDERALCC",
                                            "description": "ABOVE ₹299",
                                            "offerType": "offers",
                                            "restId": "289667",
                                            "offerLogo": "rng/md/ads/production/1acdb97aadcb61b323307845bda86535",
                                            "descriptionTextColor": "#7302060C"
                                        },
                                        "cta": {
                                            "type": "OFFER_HALF_CARD"
                                        }
                                    },
                                    {
                                        "info": {
                                            "header": "FLAT ₹120 OFF",
                                            "offerTagColor": "#E46D47",
                                            "logoBottom": "rng/md/ads/production/32b9f8a87957f8c1ca369622f6a1ca77",
                                            "offerIds": [
                                                "291c01aa-a191-457a-87bc-bff3755230c2"
                                            ],
                                            "expiryTime": "1970-01-01T00:00:00Z",
                                            "couponCode": "USE AXIS120",
                                            "description": "ABOVE ₹500",
                                            "offerType": "offers",
                                            "restId": "289667",
                                            "offerLogo": "rng/md/ads/production/32b9f8a87957f8c1ca369622f6a1ca77",
                                            "descriptionTextColor": "#7302060C"
                                        },
                                        "cta": {
                                            "type": "OFFER_HALF_CARD"
                                        }
                                    }
                                ],
                                "habitMilestoneInfo": {
                                    "callout": {}
                                }
                            }
                        }
                    }
                }
            },
            {
                "groupedCard": {
                    "cardGroupMap": {
                        "REGULAR": {
                            "cards": [
                                {
                                    "card": {
                                        "card": {
                                            "@type": "type.googleapis.com/swiggy.presentation.food.v2.MenuVegFilterAndBadge",
                                            "badges": {},
                                            "vegOnlyDetails": {
                                                "imageId": "AutoVegOnly_qkjowj",
                                                "title": "Showing only vegetarian options.",
                                                "description": "Tap on the VEG ONLY button to turn off the setting"
                                            },
                                            "topRatedFilter": {},
                                            "kidsCategoryFilter": {
                                                "attributes": {
                                                    "displayText": "Kids Favourites",
                                                    "tooltip": {
                                                        "enabled": true,
                                                        "displayText": "Kids Favourites Filter applied. Remove this filter to see the full Menu."
                                                    }
                                                }
                                            },
                                            "vegFilter": {
                                                "attributes": {
                                                    "displayText": "VEG"
                                                }
                                            },
                                            "nonvegFilter": {
                                                "attributes": {
                                                    "displayText": "NONVEG"
                                                }
                                            }
                                        }
                                    }
                                },
                                {
                                    "card": {
                                        "card": {
                                            "@type": "type.googleapis.com/swiggy.presentation.food.v2.ItemCategory",
                                            "title": "Non Vegetarian Chakhna",
                                            "itemCards": [
                                                {
                                                    "card": {
                                                        "@type": "type.googleapis.com/swiggy.presentation.food.v2.Dish",
                                                        "info": {
                                                            "id": "56244030",
                                                            "name": "Chicken Tikka",
                                                            "category": "Non Vegetarian Chakhna",
                                                            "description": "Served with green chutney & onion.",
                                                            "price": 12000,
                                                            "variants": {},
                                                            "variantsV2": {},
                                                            "itemAttribute": {
                                                                "vegClassifier": "NONVEG"
                                                            },
                                                            "ribbon": {},
                                                            "type": "ITEM",
                                                            "itemBadge": {},
                                                            "badgesV2": {},
                                                            "ratings": {
                                                                "aggregatedRating": {}
                                                            }
                                                        },
                                                        "analytics": {},
                                                        "hideRestaurantDetails": true
                                                    }
                                                },
                                                {
                                                    "card": {
                                                        "@type": "type.googleapis.com/swiggy.presentation.food.v2.Dish",
                                                        "info": {
                                                            "id": "56244031",
                                                            "name": "Chicken Malai Tikka",
                                                            "category": "Non Vegetarian Chakhna",
                                                            "description": "Served with green chutney & onion.",
                                                            "price": 12000,
                                                            "variants": {},
                                                            "variantsV2": {},
                                                            "itemAttribute": {
                                                                "vegClassifier": "NONVEG"
                                                            },
                                                            "ribbon": {},
                                                            "type": "ITEM",
                                                            "itemBadge": {},
                                                            "badgesV2": {},
                                                            "ratings": {
                                                                "aggregatedRating": {}
                                                            }
                                                        },
                                                        "analytics": {},
                                                        "hideRestaurantDetails": true
                                                    }
                                                },
                                                {
                                                    "card": {
                                                        "@type": "type.googleapis.com/swiggy.presentation.food.v2.Dish",
                                                        "info": {
                                                            "id": "56244032",
                                                            "name": "Chicken Mughlai Tikka",
                                                            "category": "Non Vegetarian Chakhna",
                                                            "description": "Served with green chutney & onion.",
                                                            "price": 12000,
                                                            "variants": {},
                                                            "variantsV2": {},
                                                            "itemAttribute": {
                                                                "vegClassifier": "NONVEG"
                                                            },
                                                            "ribbon": {},
                                                            "type": "ITEM",
                                                            "itemBadge": {},
                                                            "badgesV2": {},
                                                            "ratings": {
                                                                "aggregatedRating": {}
                                                            }
                                                        },
                                                        "analytics": {},
                                                        "hideRestaurantDetails": true
                                                    }
                                                },
                                                {
                                                    "card": {
                                                        "@type": "type.googleapis.com/swiggy.presentation.food.v2.Dish",
                                                        "info": {
                                                            "id": "56244033",
                                                            "name": "Chicken Hariyali Tikka",
                                                            "category": "Non Vegetarian Chakhna",
                                                            "description": "Served with green chutney & onion.",
                                                            "price": 12000,
                                                            "variants": {},
                                                            "variantsV2": {},
                                                            "itemAttribute": {
                                                                "vegClassifier": "NONVEG"
                                                            },
                                                            "ribbon": {},
                                                            "type": "ITEM",
                                                            "itemBadge": {},
                                                            "badgesV2": {},
                                                            "ratings": {
                                                                "aggregatedRating": {}
                                                            }
                                                        },
                                                        "analytics": {},
                                                        "hideRestaurantDetails": true
                                                    }
                                                },
                                                {
                                                    "card": {
                                                        "@type": "type.googleapis.com/swiggy.presentation.food.v2.Dish",
                                                        "info": {
                                                            "id": "56244034",
                                                            "name": "Afghani Chicken",
                                                            "category": "Non Vegetarian Chakhna",
                                                            "description": "Served with green chutney & onion.",
                                                            "price": 12800,
                                                            "variants": {},
                                                            "variantsV2": {},
                                                            "itemAttribute": {
                                                                "vegClassifier": "NONVEG"
                                                            },
                                                            "ribbon": {},
                                                            "type": "ITEM",
                                                            "itemBadge": {},
                                                            "badgesV2": {},
                                                            "ratings": {
                                                                "aggregatedRating": {}
                                                            }
                                                        },
                                                        "analytics": {},
                                                        "hideRestaurantDetails": true
                                                    }
                                                },
                                                {
                                                    "card": {
                                                        "@type": "type.googleapis.com/swiggy.presentation.food.v2.Dish",
                                                        "info": {
                                                            "id": "56244035",
                                                            "name": "Chicken Seekh Kebab (4 Pcs)",
                                                            "category": "Non Vegetarian Chakhna",
                                                            "description": "Served with green chutney & onion.",
                                                            "price": 12800,
                                                            "variants": {},
                                                            "variantsV2": {},
                                                            "itemAttribute": {
                                                                "vegClassifier": "NONVEG"
                                                            },
                                                            "ribbon": {},
                                                            "type": "ITEM",
                                                            "itemBadge": {},
                                                            "badgesV2": {},
                                                            "ratings": {
                                                                "aggregatedRating": {}
                                                            }
                                                        },
                                                        "analytics": {},
                                                        "hideRestaurantDetails": true
                                                    }
                                                },
                                                {
                                                    "card": {
                                                        "@type": "type.googleapis.com/swiggy.presentation.food.v2.Dish",
                                                        "info": {
                                                            "id": "56244036",
                                                            "name": "Chicken Badami Tikka",
                                                            "category": "Non Vegetarian Chakhna",
                                                            "description": "Served with green chutney & onion.",
                                                            "price": 12800,
                                                            "variants": {},
                                                            "variantsV2": {},
                                                            "itemAttribute": {
                                                                "vegClassifier": "NONVEG"
                                                            },
                                                            "ribbon": {},
                                                            "type": "ITEM",
                                                            "itemBadge": {},
                                                            "badgesV2": {},
                                                            "ratings": {
                                                                "aggregatedRating": {}
                                                            }
                                                        },
                                                        "analytics": {},
                                                        "hideRestaurantDetails": true
                                                    }
                                                },
                                                {
                                                    "card": {
                                                        "@type": "type.googleapis.com/swiggy.presentation.food.v2.Dish",
                                                        "info": {
                                                            "id": "56244037",
                                                            "name": "Mutton Shami Kebab (4 Pcs)",
                                                            "category": "Non Vegetarian Chakhna",
                                                            "description": "Served with green chutney & onion.",
                                                            "price": 12000,
                                                            "variants": {},
                                                            "variantsV2": {},
                                                            "itemAttribute": {
                                                                "vegClassifier": "NONVEG"
                                                            },
                                                            "ribbon": {},
                                                            "type": "ITEM",
                                                            "itemBadge": {},
                                                            "badgesV2": {},
                                                            "ratings": {
                                                                "aggregatedRating": {}
                                                            }
                                                        },
                                                        "analytics": {},
                                                        "hideRestaurantDetails": true
                                                    }
                                                }
                                            ]
                                        }
                                    }
                                },
                                {
                                    "card": {
                                        "card": {
                                            "@type": "type.googleapis.com/swiggy.presentation.food.v2.ItemCategory",
                                            "title": "Vegetarian Chakhna",
                                            "itemCards": [
                                                {
                                                    "card": {
                                                        "@type": "type.googleapis.com/swiggy.presentation.food.v2.Dish",
                                                        "info": {
                                                            "id": "56244038",
                                                            "name": "Tandoori Aloo",
                                                            "category": "Vegetarian Chakhna",
                                                            "description": "Served with green chutney & onion.",
                                                            "isVeg": 1,
                                                            "price": 8800,
                                                            "variants": {},
                                                            "variantsV2": {},
                                                            "itemAttribute": {
                                                                "vegClassifier": "VEG"
                                                            },
                                                            "ribbon": {},
                                                            "type": "ITEM",
                                                            "itemBadge": {},
                                                            "badgesV2": {},
                                                            "ratings": {
                                                                "aggregatedRating": {}
                                                            }
                                                        },
                                                        "analytics": {},
                                                        "hideRestaurantDetails": true
                                                    }
                                                },
                                                {
                                                    "card": {
                                                        "@type": "type.googleapis.com/swiggy.presentation.food.v2.Dish",
                                                        "info": {
                                                            "id": "56244039",
                                                            "name": "Chilli Paneer",
                                                            "category": "Vegetarian Chakhna",
                                                            "description": "Served with green chutney & onion.",
                                                            "isVeg": 1,
                                                            "price": 9600,
                                                            "variants": {},
                                                            "variantsV2": {},
                                                            "itemAttribute": {
                                                                "vegClassifier": "VEG"
                                                            },
                                                            "ribbon": {},
                                                            "type": "ITEM",
                                                            "itemBadge": {},
                                                            "badgesV2": {},
                                                            "ratings": {
                                                                "aggregatedRating": {}
                                                            }
                                                        },
                                                        "analytics": {},
                                                        "hideRestaurantDetails": true
                                                    }
                                                },
                                                {
                                                    "card": {
                                                        "@type": "type.googleapis.com/swiggy.presentation.food.v2.Dish",
                                                        "info": {
                                                            "id": "56244040",
                                                            "name": "Paneer Tikka",
                                                            "category": "Vegetarian Chakhna",
                                                            "description": "Served with green chutney & onion.",
                                                            "isVeg": 1,
                                                            "price": 10400,
                                                            "variants": {},
                                                            "variantsV2": {},
                                                            "itemAttribute": {
                                                                "vegClassifier": "VEG"
                                                            },
                                                            "ribbon": {},
                                                            "type": "ITEM",
                                                            "itemBadge": {},
                                                            "badgesV2": {},
                                                            "ratings": {
                                                                "aggregatedRating": {}
                                                            }
                                                        },
                                                        "analytics": {},
                                                        "hideRestaurantDetails": true
                                                    }
                                                },
                                                {
                                                    "card": {
                                                        "@type": "type.googleapis.com/swiggy.presentation.food.v2.Dish",
                                                        "info": {
                                                            "id": "56244041",
                                                            "name": "Paneer Malai Tikka",
                                                            "category": "Vegetarian Chakhna",
                                                            "description": "Served with green chutney & onion.",
                                                            "isVeg": 1,
                                                            "price": 10400,
                                                            "variants": {},
                                                            "variantsV2": {},
                                                            "itemAttribute": {
                                                                "vegClassifier": "VEG"
                                                            },
                                                            "ribbon": {},
                                                            "type": "ITEM",
                                                            "itemBadge": {},
                                                            "badgesV2": {},
                                                            "ratings": {
                                                                "aggregatedRating": {}
                                                            }
                                                        },
                                                        "analytics": {},
                                                        "hideRestaurantDetails": true
                                                    }
                                                },
                                                {
                                                    "card": {
                                                        "@type": "type.googleapis.com/swiggy.presentation.food.v2.Dish",
                                                        "info": {
                                                            "id": "56244042",
                                                            "name": "Paneer Reshmi Tikka",
                                                            "category": "Vegetarian Chakhna",
                                                            "description": "Served with green chutney & onion.",
                                                            "isVeg": 1,
                                                            "price": 10400,
                                                            "variants": {},
                                                            "variantsV2": {},
                                                            "itemAttribute": {
                                                                "vegClassifier": "VEG"
                                                            },
                                                            "ribbon": {},
                                                            "type": "ITEM",
                                                            "itemBadge": {},
                                                            "badgesV2": {},
                                                            "ratings": {
                                                                "aggregatedRating": {}
                                                            }
                                                        },
                                                        "analytics": {},
                                                        "hideRestaurantDetails": true
                                                    }
                                                },
                                                {
                                                    "card": {
                                                        "@type": "type.googleapis.com/swiggy.presentation.food.v2.Dish",
                                                        "info": {
                                                            "id": "56244043",
                                                            "name": "Veg Seekh Kebab (4 Pcs)",
                                                            "category": "Vegetarian Chakhna",
                                                            "description": "Served with green chutney & onion.",
                                                            "isVeg": 1,
                                                            "price": 10400,
                                                            "variants": {},
                                                            "variantsV2": {},
                                                            "itemAttribute": {
                                                                "vegClassifier": "VEG"
                                                            },
                                                            "ribbon": {},
                                                            "type": "ITEM",
                                                            "itemBadge": {},
                                                            "badgesV2": {},
                                                            "ratings": {
                                                                "aggregatedRating": {}
                                                            }
                                                        },
                                                        "analytics": {},
                                                        "hideRestaurantDetails": true
                                                    }
                                                },
                                                {
                                                    "card": {
                                                        "@type": "type.googleapis.com/swiggy.presentation.food.v2.Dish",
                                                        "info": {
                                                            "id": "56244044",
                                                            "name": "Soya Chaap",
                                                            "category": "Vegetarian Chakhna",
                                                            "description": "Served with green chutney & onion.",
                                                            "isVeg": 1,
                                                            "price": 10400,
                                                            "variants": {},
                                                            "variantsV2": {},
                                                            "itemAttribute": {
                                                                "vegClassifier": "VEG"
                                                            },
                                                            "ribbon": {},
                                                            "type": "ITEM",
                                                            "itemBadge": {},
                                                            "badgesV2": {},
                                                            "ratings": {
                                                                "aggregatedRating": {}
                                                            }
                                                        },
                                                        "analytics": {},
                                                        "hideRestaurantDetails": true
                                                    }
                                                },
                                                {
                                                    "card": {
                                                        "@type": "type.googleapis.com/swiggy.presentation.food.v2.Dish",
                                                        "info": {
                                                            "id": "56244045",
                                                            "name": "Mushroom Tikka",
                                                            "category": "Vegetarian Chakhna",
                                                            "description": "Served with green chutney & onion.",
                                                            "isVeg": 1,
                                                            "price": 11200,
                                                            "variants": {},
                                                            "variantsV2": {},
                                                            "itemAttribute": {
                                                                "vegClassifier": "VEG"
                                                            },
                                                            "ribbon": {},
                                                            "type": "ITEM",
                                                            "itemBadge": {},
                                                            "badgesV2": {},
                                                            "ratings": {
                                                                "aggregatedRating": {}
                                                            }
                                                        },
                                                        "analytics": {},
                                                        "hideRestaurantDetails": true
                                                    }
                                                }
                                            ]
                                        }
                                    }
                                },
                                {
                                    "card": {
                                        "card": {
                                            "@type": "type.googleapis.com/swiggy.presentation.food.v2.RestaurantAddress",
                                            "name": "CHAKHNA DE BHAI",
                                            "area": "Civil Lines",
                                            "completeAddress": "Civil lines Allahabad Payangraj , Allahabad ,211001"
                                        }
                                    }
                                }
                            ]
                        }
                    }
                }
            }
        ],
        "firstOffsetRequest": true,
        "isQCLink": false
    },
    "tid": "aecc0c94-6186-48a8-801a-9c35b33ef4d1",
    "sid": "ayae2986-db3b-4540-a014-7e8d5f928e34",
    "deviceId": "336c13e4-49df-56cc-8eb5-fad24878b416",
    "csrfToken": null
}