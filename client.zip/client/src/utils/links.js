export const LOGO_URL = "https://cdn.dribbble.com/users/1635051/screenshots/4291569/socio_curry_logo-01.png"
export const CDN_URL = "https://media-assets.swiggy.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_660/"



export const API_URL =  "https://api.allorigins.win/raw?url=https%3A%2F%2Fwww.swiggy.com%2Fdapi%2Frestaurants%2Flist%2Fv5%3Flat%3D22.5743545%26lng%3D88.3628734%26is-seo-homepage-enabled%3Dtrue%26page_type%3DDESKTOP_WEB_LISTING"




export const MENU_API = 'https://api.allorigins.win/raw?url=https%3A%2F%2Fwww.swiggy.com%2Fdapi%2Fmenu%2Fpl%3Fpage-type%3DREGULAR_MENU%26complete-menu%3Dtrue%26lat%3D15.8323892%26lng%3D78.0544946%26restaurantId=';

    
