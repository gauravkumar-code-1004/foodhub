import { useEffect } from "react";
import { useDispatch } from "react-redux";
import { MENU_API } from "../links";
import { addMenu } from "../restroSlice";





const useMenu = (resID) => {

    const dispatch = useDispatch();


    const Id = resID.id;
    
    

    const fetchMenu = async () => {
        // let data = await fetch(MENU_API + Id);
        let data = await fetch(MENU_API + "361755");
        const json = await data.json();
        const category = json?.data?.cards[4]?.groupedCard?.cardGroupMap?.REGULAR;
        console.log(category)
        const itemcard = category?.cards;
        const typeString = "type.googleapis.com/swiggy.presentation.food.v2.ItemCategory"

        const type = itemcard?.filter((item) => item.card?.card?.["@type"] === typeString)
        
        dispatch(addMenu(type))





    }


    useEffect(() => {
        fetchMenu()


    }, [])




}

export default useMenu;
